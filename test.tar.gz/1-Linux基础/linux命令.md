## 

    ls: 展示文件目录

        -a 列出目录下的所有文件，包括以 . 开头的隐含文件.
        -l 列出文件的详细信息.
        -s 在每个文件名后输出该文件的大小.
        -u 以文件上次被访问的时间排序.
        -t 以时间排序.
        -h 显示文件大小时增加可读性.
        -S 以文件大小排序.
        -R 列出所有子目录下的文件.



    more: 展示文件内容

        +n 从第n行开始显示
        -n 定义屏幕大小为n行     
        -c 从顶部清屏，然后显示   
        -l 忽略Ctrl+l（换页）字符

            常用指令：
                Enter       向下n行，需要定义。默认为1行
                Ctrl+F      向下滚动一屏
                空格键       向下滚动一屏
                Ctrl+B      返回上一屏
                =           输出当前行的行号
                ：f         输出文件名和当前行的行号
                V           调用vi编辑器
                !命令        调用Shell，并执行命令 
                q           退出more

        
    cat: 重定向

        cat file    一次性显示文件全部内容
        cat >file   创建一个文件
        cat file1 file2 > file3     合并文件   
        cat -n file1 > file2        从第n行开始
        cat -n [number] file        从第几行，显示行号，默认是1

    

    
    less: 分页显示
        
        less file

            q: 退出
            h: 帮助
            空格: 下一页
            b: 上一页
            g: 第一行
            G: 结尾




    head/tail:

        head -n file    显示文件头n行
        tail -n file    显示文件后n行
        tail -f file    循环读取
        

    chown 权限
        
        chown [选项]...[所有者][:组] 文件...   

        chown root file     更改用户，改变用户。

            -R 处理指定目录以及其子目录下的所有文件
            -v 显示详细的处理信息
        

            

    chmod  权限

        r ：读权限，用数字4表示
        w ：写权限，用数字2表示
        x ：执行权限，用数字1表示
        R : 对于一个目录所有子文件添加权限



    

    tar／gzip : 打包、压缩、解压缩

        tar : 打包用的
                -A 新增压缩文件到已存在的压缩
                -B 设置区块大小
                -c 建立新的压缩文件
                -d 记录文件的差别
                -r 添加文件到已经压缩的文件
                -u 添加改变了和现有的文件到已经存在的压缩文件
                -x 从压缩的文件中提取文件
                -t 显示压缩文件的内容
                -z 支持gzip解压文件
                -j 支持bzip2解压文件
                -Z 支持compress解压文件
                -v 显示操作过程
                -l 文件系统边界设置
                -k 保留原有文件不覆盖
                -m 保留文件不被覆盖
                -W 确认压缩文件的正确性
                
                可选参数如下：
                    -b 设置区块数目
                    -C 切换到指定目录
                    -f 指定压缩文件                
    

            tar -cvf /tmp/etc.tar           /etc    <==仅打包，不压缩！
            tar -zcvf /tmp/etc.tar.gz       /etc    <==打包后，以 gzip 压缩
            tar -jcvf /tmp/etc.tar.bz2      /etc    <==打包后，以 bzip2 压缩








    , chmod, chown, ssh, scp，grep，iostat，vmstat，sed，awk






## 
    我参考了这个人分享的
        http://www.cnblogs.com/peida/tag/linux%E5%91%BD%E4%BB%A4/   






## df, du，lsof，join，find，top，ps
